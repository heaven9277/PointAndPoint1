package com.example.zhw.piontandpiont2.Bean;

public class LoginSuccessData {
    private String groupName,groupNumber,groupPortrait,lastestGroupUser, lastGroupNumberName,
            lastGroupSendTime,lastestGroupMessage,groupMessageCount,groupRole;
    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    public String getGroupPortrait() {
        return groupPortrait;
    }

    public void setGroupPortrait(String groupPortrait) {
        this.groupPortrait = groupPortrait;
    }

    public String getLastestGroupUser() {
        return lastestGroupUser;
    }

    public void setLastestGroupUser(String lastestGroupUser) {
        this.lastestGroupUser = lastestGroupUser;
    }

    public String getLastGroupNumberName() {
        return lastGroupNumberName;
    }

    public void setLastGroupNumberName(String lastGroupNumberName) {
        this.lastGroupNumberName = lastGroupNumberName;
    }

    public String getLastGroupSendTime() {
        return lastGroupSendTime;
    }

    public void setLastGroupSendTime(String lastGroupSendTime) {
        this.lastGroupSendTime = lastGroupSendTime;
    }

    public String getLastestGroupMessage() {
        return lastestGroupMessage;
    }

    public void setLastestGroupMessage(String lastestGroupMessage) {
        this.lastestGroupMessage = lastestGroupMessage;
    }

    public String getGroupMessageCount() {
        return groupMessageCount;
    }

    public void setGroupMessageCount(String groupMessageCount) {
        this.groupMessageCount = groupMessageCount;
    }

    public String getGroupRole() {
        return groupRole;
    }

    public void setGroupRole(String groupRole) {
        this.groupRole = groupRole;
    }
}
