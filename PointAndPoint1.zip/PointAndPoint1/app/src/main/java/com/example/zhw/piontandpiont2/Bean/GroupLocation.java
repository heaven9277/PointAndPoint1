package com.example.zhw.piontandpiont2.Bean;

//查看群成员位置信息
//操作码8
public class GroupLocation {

    private String userName,userPortrait,userLocationLongitude,userLocationLatitude,userLocationCorner,userLocationTime;

    public String getUserName() {
        return userName;
    }

    public String getUserPortrait() {
        return userPortrait;
    }

    public String getUserLocationLongitude() {
        return userLocationLongitude;
    }

    public String getUserLocationLatitude() {
        return userLocationLatitude;
    }

    public String getUserLocationCorner() {
        return userLocationCorner;
    }

    public String getUserLocationTime() {
        return userLocationTime;
    }
}
