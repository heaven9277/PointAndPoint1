package com.example.zhw.piontandpiont2.Networksockets;

public class AdressHttp {
    private static String url = "172.17.146.126:8080/";
    public static String getUrl(){
        return "http://"+url;
    }
}
